import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { User, Meal, DailyNutrition } from '../types';

interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  currentMeal: Meal | null;
  dailyNutrition: DailyNutrition | null;
  mealHistory: Meal[];
  isLoading: boolean;
  activeView: 'upload' | 'results' | 'dashboard' | 'history';
}

type AppAction =
  | { type: 'SET_USER'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'SET_CURRENT_MEAL'; payload: Meal }
  | { type: 'SET_DAILY_NUTRITION'; payload: DailyNutrition }
  | { type: 'ADD_MEAL'; payload: Meal }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ACTIVE_VIEW'; payload: AppState['activeView'] };

const initialState: AppState = {
  user: {
    id: '1',
    name: 'Demo User',
    email: 'demo@nutrivision.com',
    dailyCalorieGoal: 2000,
    joinedDate: '2024-01-01'
  },
  isAuthenticated: true,
  currentMeal: null,
  dailyNutrition: null,
  mealHistory: [],
  isLoading: false,
  activeView: 'upload'
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload, isAuthenticated: true };
    case 'LOGOUT':
      return { ...state, user: null, isAuthenticated: false };
    case 'SET_CURRENT_MEAL':
      return { ...state, currentMeal: action.payload };
    case 'SET_DAILY_NUTRITION':
      return { ...state, dailyNutrition: action.payload };
    case 'ADD_MEAL':
      return { 
        ...state, 
        mealHistory: [action.payload, ...state.mealHistory],
        currentMeal: action.payload
      };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ACTIVE_VIEW':
      return { ...state, activeView: action.payload };
    default:
      return state;
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}