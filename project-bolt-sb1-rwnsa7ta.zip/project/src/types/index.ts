export interface User {
  id: string;
  name: string;
  email: string;
  dailyCalorieGoal: number;
  joinedDate: string;
}

export interface FoodItem {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
  confidence: number;
  portion: string;
  healthRating: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  healthColor: string;
}

export interface Meal {
  id: string;
  date: string;
  time: string;
  imageUrl: string;
  foodItems: FoodItem[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
}

export interface DailyNutrition {
  date: string;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  totalFiber: number;
  meals: Meal[];
  calorieGoal: number;
}

export interface AnalysisResult {
  success: boolean;
  foodItems: FoodItem[];
  totalNutrition: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
  };
  healthTips: string[];
  overallHealthRating: string;
}