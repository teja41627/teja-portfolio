import React from 'react';
import { ArrowLeft, Utensils, Flame, Shield, TrendingUp } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function AnalysisResults() {
  const { state, dispatch } = useApp();
  const meal = state.currentMeal;

  if (!meal) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">No meal data available</p>
        <button
          onClick={() => dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'upload' })}
          className="btn-primary mt-4"
        >
          Analyze a Meal
        </button>
      </div>
    );
  }

  const macroData = [
    { name: 'Protein', value: meal.totalProtein, color: 'text-blue-600', bg: 'bg-blue-100' },
    { name: 'Carbs', value: meal.totalCarbs, color: 'text-green-600', bg: 'bg-green-100' },
    { name: 'Fat', value: meal.totalFat, color: 'text-yellow-600', bg: 'bg-yellow-100' },
  ];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex items-center mb-6">
        <button
          onClick={() => dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'upload' })}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors duration-200"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Upload</span>
        </button>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Image and Overview */}
        <div className="space-y-6">
          <div className="card">
            <img 
              src={meal.imageUrl} 
              alt="Analyzed meal" 
              className="w-full h-64 object-cover rounded-xl mb-4"
            />
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {meal.mealType.charAt(0).toUpperCase() + meal.mealType.slice(1)}
                </h3>
                <p className="text-gray-600">{meal.date} at {meal.time}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-emerald-600">
                  {meal.totalCalories}
                </p>
                <p className="text-gray-600 text-sm">calories</p>
              </div>
            </div>
          </div>

          {/* Macronutrients */}
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-emerald-600" />
              Macronutrients
            </h3>
            <div className="grid grid-cols-3 gap-4">
              {macroData.map((macro) => (
                <div key={macro.name} className="text-center">
                  <div className={`w-16 h-16 rounded-full ${macro.bg} flex items-center justify-center mx-auto mb-2`}>
                    <span className={`text-xl font-bold ${macro.color}`}>
                      {Math.round(macro.value)}g
                    </span>
                  </div>
                  <p className="text-sm font-medium text-gray-700">{macro.name}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Food Items */}
        <div className="space-y-6">
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Utensils className="w-5 h-5 mr-2 text-emerald-600" />
              Detected Food Items
            </h3>
            <div className="space-y-4">
              {meal.foodItems.map((item, index) => (
                <div key={index} className="border border-gray-200 rounded-xl p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-semibold text-gray-900">{item.name}</h4>
                      <p className="text-sm text-gray-600">{item.portion}</p>
                    </div>
                    <div className="text-right">
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${item.healthColor} bg-opacity-10`}>
                        {item.healthRating}
                      </span>
                      <p className="text-xs text-gray-500 mt-1">
                        {Math.round(item.confidence * 100)}% confidence
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Calories</p>
                      <p className="font-semibold">{item.calories}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Protein</p>
                      <p className="font-semibold">{item.protein}g</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Carbs</p>
                      <p className="font-semibold">{item.carbs}g</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Fat</p>
                      <p className="font-semibold">{item.fat}g</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Health Tips */}
          <div className="card bg-gradient-to-br from-emerald-50 to-blue-50">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Shield className="w-5 h-5 mr-2 text-emerald-600" />
              Health Insights
            </h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 mb-3">
                <Flame className="w-5 h-5 text-orange-500" />
                <span className="font-medium text-gray-900">Overall Rating: </span>
                <span className="font-semibold text-emerald-600">Balanced Meal</span>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">Great protein content helps with muscle maintenance and keeps you full longer.</p>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">Well-balanced macronutrients provide sustained energy throughout the day.</p>
                </li>
                <li className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">Consider adding more vegetables to increase fiber and micronutrient content.</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 flex justify-center space-x-4">
        <button
          onClick={() => dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'dashboard' })}
          className="btn-primary"
        >
          View Dashboard
        </button>
        <button
          onClick={() => dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'upload' })}
          className="btn-secondary"
        >
          Analyze Another Meal
        </button>
      </div>
    </div>
  );
}