import React from 'react';
import { Target, TrendingUp, Calendar, Award } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function Dashboard() {
  const { state } = useApp();
  const user = state.user;
  const todaysMeals = state.mealHistory.filter(meal => 
    meal.date === new Date().toISOString().split('T')[0]
  );

  const todaysCalories = todaysMeals.reduce((sum, meal) => sum + meal.totalCalories, 0);
  const todaysProtein = todaysMeals.reduce((sum, meal) => sum + meal.totalProtein, 0);
  const todaysCarbs = todaysMeals.reduce((sum, meal) => sum + meal.totalCarbs, 0);
  const todaysFat = todaysMeals.reduce((sum, meal) => sum + meal.totalFat, 0);

  const calorieProgress = user ? (todaysCalories / user.dailyCalorieGoal) * 100 : 0;

  const stats = [
    {
      title: 'Today\'s Calories',
      value: todaysCalories,
      goal: user?.dailyCalorieGoal || 2000,
      unit: 'kcal',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-100',
      progress: calorieProgress
    },
    {
      title: 'Protein',
      value: Math.round(todaysProtein),
      goal: 150,
      unit: 'g',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      progress: (todaysProtein / 150) * 100
    },
    {
      title: 'Carbs',
      value: Math.round(todaysCarbs),
      goal: 250,
      unit: 'g',
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      progress: (todaysCarbs / 250) * 100
    },
    {
      title: 'Fat',
      value: Math.round(todaysFat),
      goal: 65,
      unit: 'g',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100',
      progress: (todaysFat / 65) * 100
    }
  ];

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">
          Welcome back, {user?.name}!
        </h2>
        <p className="text-gray-600 text-lg">
          Here's your nutrition overview for today
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="card">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 rounded-full ${stat.bgColor} flex items-center justify-center`}>
                <Target className={`w-6 h-6 ${stat.color}`} />
              </div>
              <span className="text-sm text-gray-600">{stat.title}</span>
            </div>
            
            <div className="mb-3">
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-bold text-gray-900">
                  {stat.value}
                </span>
                <span className="text-gray-600">/ {stat.goal} {stat.unit}</span>
              </div>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${stat.bgColor.replace('bg-', 'bg-').replace('-100', '-500')}`}
                style={{ width: `${Math.min(stat.progress, 100)}%` }}
              ></div>
            </div>
            
            <p className="text-xs text-gray-600 mt-2">
              {Math.round(stat.progress)}% of daily goal
            </p>
          </div>
        ))}
      </div>

      {/* Today's Meals */}
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="card">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-emerald-600" />
            Today's Meals
          </h3>
          
          {todaysMeals.length > 0 ? (
            <div className="space-y-4">
              {todaysMeals.map((meal, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 border border-gray-200 rounded-xl">
                  <img 
                    src={meal.imageUrl} 
                    alt={meal.mealType}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 capitalize">
                      {meal.mealType}
                    </h4>
                    <p className="text-sm text-gray-600">{meal.time}</p>
                    <p className="text-sm font-medium text-emerald-600">
                      {meal.totalCalories} calories
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No meals logged yet today</p>
              <p className="text-sm text-gray-500">Start by analyzing your first meal!</p>
            </div>
          )}
        </div>

        {/* Health Insights */}
        <div className="card bg-gradient-to-br from-emerald-50 to-blue-50">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Award className="w-5 h-5 mr-2 text-emerald-600" />
            Health Insights
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2 flex-shrink-0"></div>
              <div>
                <h4 className="font-medium text-gray-900">Calorie Balance</h4>
                <p className="text-sm text-gray-600">
                  {calorieProgress < 80 
                    ? "You're under your calorie goal. Consider adding a healthy snack."
                    : calorieProgress > 120
                    ? "You've exceeded your calorie goal. Focus on lighter meals tomorrow."
                    : "Great job maintaining your calorie balance today!"
                  }
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
              <div>
                <h4 className="font-medium text-gray-900">Protein Intake</h4>
                <p className="text-sm text-gray-600">
                  {todaysProtein < 100
                    ? "Consider adding more protein sources like lean meats, eggs, or legumes."
                    : "Excellent protein intake! This supports muscle health and satiety."
                  }
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-600 rounded-full mt-2 flex-shrink-0"></div>
              <div>
                <h4 className="font-medium text-gray-900">Weekly Progress</h4>
                <p className="text-sm text-gray-600">
                  You've logged {state.mealHistory.length} meals this week. 
                  Consistency is key to reaching your health goals!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 text-center">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="flex justify-center space-x-4">
          <button 
            onClick={() => state.dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'upload' })}
            className="btn-primary"
          >
            Analyze New Meal
          </button>
          <button 
            onClick={() => state.dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'history' })}
            className="btn-secondary"
          >
            View Full History
          </button>
        </div>
      </div>
    </div>
  );
}