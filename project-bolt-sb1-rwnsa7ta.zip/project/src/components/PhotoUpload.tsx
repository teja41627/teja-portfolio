import React, { useState, useRef } from 'react';
import { Camera, Upload, Image as ImageIcon, Loader2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { analyzeFood } from '../services/foodRecognition';

export function PhotoUpload() {
  const { dispatch } = useApp();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    const imageUrl = URL.createObjectURL(file);
    setSelectedImage(imageUrl);
    setIsAnalyzing(true);
    dispatch({ type: 'SET_LOADING', payload: true });

    try {
      const result = await analyzeFood(file);
      
      if (result.success) {
        const newMeal = {
          id: Date.now().toString(),
          date: new Date().toISOString().split('T')[0],
          time: new Date().toLocaleTimeString(),
          imageUrl,
          foodItems: result.foodItems,
          totalCalories: result.totalNutrition.calories,
          totalProtein: result.totalNutrition.protein,
          totalCarbs: result.totalNutrition.carbs,
          totalFat: result.totalNutrition.fat,
          mealType: getCurrentMealType()
        };

        dispatch({ type: 'ADD_MEAL', payload: newMeal });
        dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'results' });
      }
    } catch (error) {
      console.error('Analysis failed:', error);
      alert('Failed to analyze the image. Please try again.');
    } finally {
      setIsAnalyzing(false);
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const getCurrentMealType = (): 'breakfast' | 'lunch' | 'dinner' | 'snack' => {
    const hour = new Date().getHours();
    if (hour < 10) return 'breakfast';
    if (hour < 15) return 'lunch';
    if (hour < 20) return 'dinner';
    return 'snack';
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleCameraClick = () => {
    cameraInputRef.current?.click();
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">
          Analyze Your Meal
        </h2>
        <p className="text-gray-600 text-lg">
          Upload or take a photo to get instant nutritional analysis
        </p>
      </div>

      {selectedImage && (
        <div className="mb-8 card">
          <img 
            src={selectedImage} 
            alt="Selected meal" 
            className="w-full h-64 object-cover rounded-xl mb-4"
          />
          {isAnalyzing && (
            <div className="flex items-center justify-center space-x-3 py-4">
              <Loader2 className="w-6 h-6 text-emerald-600 animate-spin" />
              <span className="text-lg font-medium text-gray-700">
                Analyzing your meal...
              </span>
            </div>
          )}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <button
          onClick={handleUploadClick}
          disabled={isAnalyzing}
          className="card hover:shadow-xl transition-all duration-300 group disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="flex flex-col items-center space-y-4 py-8">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center group-hover:bg-emerald-200 transition-colors duration-200">
              <Upload className="w-8 h-8 text-emerald-600" />
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Upload Photo
              </h3>
              <p className="text-gray-600">
                Select an image from your device
              </p>
            </div>
          </div>
        </button>

        <button
          onClick={handleCameraClick}
          disabled={isAnalyzing}
          className="card hover:shadow-xl transition-all duration-300 group disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="flex flex-col items-center space-y-4 py-8">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center group-hover:bg-blue-200 transition-colors duration-200">
              <Camera className="w-8 h-8 text-blue-600" />
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Take Photo
              </h3>
              <p className="text-gray-600">
                Use your camera to capture the meal
              </p>
            </div>
          </div>
        </button>
      </div>

      <div className="card bg-gradient-to-br from-emerald-50 to-blue-50">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
            <ImageIcon className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Tips for Best Results
            </h3>
            <ul className="text-gray-600 space-y-1 text-sm">
              <li>• Ensure good lighting when taking photos</li>
              <li>• Keep the food clearly visible and in focus</li>
              <li>• Include the entire meal in the frame</li>
              <li>• Avoid shadows or reflections on the food</li>
            </ul>
          </div>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
        className="hidden"
      />
      
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
        className="hidden"
      />
    </div>
  );
}