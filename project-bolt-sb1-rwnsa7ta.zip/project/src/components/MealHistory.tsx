import React, { useState } from 'react';
import { Calendar, Clock, Utensils, TrendingUp, Filter } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function MealHistory() {
  const { state } = useApp();
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'breakfast' | 'lunch' | 'dinner' | 'snack'>('all');
  const [selectedDate, setSelectedDate] = useState<string>('');

  const filteredMeals = state.mealHistory.filter(meal => {
    const matchesType = selectedFilter === 'all' || meal.mealType === selectedFilter;
    const matchesDate = !selectedDate || meal.date === selectedDate;
    return matchesType && matchesDate;
  });

  const totalCaloriesAllTime = state.mealHistory.reduce((sum, meal) => sum + meal.totalCalories, 0);
  const averageCaloriesPerMeal = state.mealHistory.length > 0 
    ? Math.round(totalCaloriesAllTime / state.mealHistory.length) 
    : 0;

  const mealTypeColors = {
    breakfast: 'bg-yellow-100 text-yellow-800',
    lunch: 'bg-green-100 text-green-800',
    dinner: 'bg-blue-100 text-blue-800',
    snack: 'bg-purple-100 text-purple-800'
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Meal History</h2>
        <p className="text-gray-600 text-lg">
          Track your nutrition journey over time
        </p>
      </div>

      {/* Summary Stats */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="card">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center">
              <Utensils className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Meals</p>
              <p className="text-2xl font-bold text-gray-900">
                {state.mealHistory.length}
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Calories</p>
              <p className="text-2xl font-bold text-gray-900">
                {totalCaloriesAllTime.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Avg per Meal</p>
              <p className="text-2xl font-bold text-gray-900">
                {averageCaloriesPerMeal}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <Filter className="w-5 h-5 text-gray-600" />
            <div className="flex space-x-2">
              {['all', 'breakfast', 'lunch', 'dinner', 'snack'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setSelectedFilter(filter as any)}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors duration-200 ${
                    selectedFilter === filter
                      ? 'bg-emerald-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {filter.charAt(0).toUpperCase() + filter.slice(1)}
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-gray-600" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="input-field text-sm"
            />
          </div>
        </div>
      </div>

      {/* Meal List */}
      {filteredMeals.length > 0 ? (
        <div className="grid gap-6">
          {filteredMeals.map((meal, index) => (
            <div key={index} className="card hover:shadow-xl transition-all duration-300">
              <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-6">
                <img 
                  src={meal.imageUrl} 
                  alt={meal.mealType}
                  className="w-full md:w-32 h-32 object-cover rounded-xl"
                />
                
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center space-x-3 mb-2">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${mealTypeColors[meal.mealType]}`}>
                          {meal.mealType.charAt(0).toUpperCase() + meal.mealType.slice(1)}
                        </span>
                        <div className="flex items-center space-x-1 text-gray-600">
                          <Calendar className="w-4 h-4" />
                          <span className="text-sm">{meal.date}</span>
                        </div>
                        <div className="flex items-center space-x-1 text-gray-600">
                          <Clock className="w-4 h-4" />
                          <span className="text-sm">{meal.time}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-emerald-600">
                        {meal.totalCalories}
                      </p>
                      <p className="text-sm text-gray-600">calories</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <p className="text-lg font-semibold text-blue-600">
                        {Math.round(meal.totalProtein)}g
                      </p>
                      <p className="text-sm text-gray-600">Protein</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-green-600">
                        {Math.round(meal.totalCarbs)}g
                      </p>
                      <p className="text-sm text-gray-600">Carbs</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-yellow-600">
                        {Math.round(meal.totalFat)}g
                      </p>
                      <p className="text-sm text-gray-600">Fat</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {meal.foodItems.map((item, itemIndex) => (
                      <span 
                        key={itemIndex}
                        className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-sm"
                      >
                        {item.name}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card text-center py-12">
          <Utensils className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No meals found
          </h3>
          <p className="text-gray-600 mb-4">
            {selectedFilter !== 'all' || selectedDate 
              ? 'Try adjusting your filters to see more meals'
              : 'Start by analyzing your first meal to build your history'
            }
          </p>
          <button 
            onClick={() => {
              setSelectedFilter('all');
              setSelectedDate('');
            }}
            className="btn-secondary mr-3"
          >
            Clear Filters
          </button>
          <button 
            onClick={() => state.dispatch({ type: 'SET_ACTIVE_VIEW', payload: 'upload' })}
            className="btn-primary"
          >
            Analyze New Meal
          </button>
        </div>
      )}
    </div>
  );
}