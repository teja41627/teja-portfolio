import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { PhotoUpload } from './components/PhotoUpload';
import { AnalysisResults } from './components/AnalysisResults';
import { Dashboard } from './components/Dashboard';
import { MealHistory } from './components/MealHistory';

function AppContent() {
  const { state } = useApp();

  const renderActiveView = () => {
    switch (state.activeView) {
      case 'upload':
        return <PhotoUpload />;
      case 'results':
        return <AnalysisResults />;
      case 'dashboard':
        return <Dashboard />;
      case 'history':
        return <MealHistory />;
      default:
        return <PhotoUpload />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="py-8">
        <div className="fade-in">
          {renderActiveView()}
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;