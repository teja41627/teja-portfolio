import { FoodItem, AnalysisResult } from '../types';

// Mock food database with nutritional information
const FOOD_DATABASE: Record<string, Omit<FoodItem, 'confidence'>> = {
  'grilled chicken breast': {
    name: 'Grilled Chicken Breast',
    calories: 165,
    protein: 31,
    carbs: 0,
    fat: 3.6,
    fiber: 0,
    sugar: 0,
    sodium: 74,
    portion: '100g serving',
    healthRating: 'Excellent',
    healthColor: 'text-green-600'
  },
  'brown rice': {
    name: 'Brown Rice',
    calories: 112,
    protein: 2.6,
    carbs: 23,
    fat: 0.9,
    fiber: 1.8,
    sugar: 0.4,
    sodium: 5,
    portion: '100g cooked',
    healthRating: 'Good',
    healthColor: 'text-green-500'
  },
  'broccoli': {
    name: 'Steamed Broccoli',
    calories: 25,
    protein: 2.6,
    carbs: 5,
    fat: 0.4,
    fiber: 3,
    sugar: 1.5,
    sodium: 41,
    portion: '100g serving',
    healthRating: 'Excellent',
    healthColor: 'text-green-600'
  },
  'salmon': {
    name: 'Grilled Salmon',
    calories: 206,
    protein: 22,
    carbs: 0,
    fat: 12,
    fiber: 0,
    sugar: 0,
    sodium: 59,
    portion: '100g serving',
    healthRating: 'Excellent',
    healthColor: 'text-green-600'
  },
  'pizza': {
    name: 'Cheese Pizza Slice',
    calories: 285,
    protein: 12,
    carbs: 36,
    fat: 10,
    fiber: 2,
    sugar: 4,
    sodium: 640,
    portion: '1 slice',
    healthRating: 'Fair',
    healthColor: 'text-yellow-600'
  },
  'burger': {
    name: 'Beef Burger',
    calories: 540,
    protein: 25,
    carbs: 40,
    fat: 31,
    fiber: 3,
    sugar: 5,
    sodium: 1040,
    portion: '1 medium burger',
    healthRating: 'Poor',
    healthColor: 'text-red-600'
  },
  'salad': {
    name: 'Mixed Green Salad',
    calories: 35,
    protein: 3,
    carbs: 7,
    fat: 0.3,
    fiber: 2,
    sugar: 4,
    sodium: 15,
    portion: '100g serving',
    healthRating: 'Excellent',
    healthColor: 'text-green-600'
  },
  'apple': {
    name: 'Fresh Apple',
    calories: 52,
    protein: 0.3,
    carbs: 14,
    fat: 0.2,
    fiber: 2.4,
    sugar: 10,
    sodium: 1,
    portion: '1 medium apple',
    healthRating: 'Excellent',
    healthColor: 'text-green-600'
  }
};

// Simulate AI food recognition
function recognizeFoodItems(imageFile: File): FoodItem[] {
  // Simulate processing time and AI recognition
  const fileName = imageFile.name.toLowerCase();
  const recognizedItems: FoodItem[] = [];
  
  // Simple keyword matching to simulate AI recognition
  Object.entries(FOOD_DATABASE).forEach(([key, food]) => {
    if (fileName.includes(key.split(' ')[0]) || Math.random() > 0.7) {
      recognizedItems.push({
        ...food,
        confidence: Math.random() * 0.3 + 0.7 // 70-100% confidence
      });
    }
  });
  
  // Ensure at least one item is recognized
  if (recognizedItems.length === 0) {
    const randomFood = Object.values(FOOD_DATABASE)[Math.floor(Math.random() * Object.values(FOOD_DATABASE).length)];
    recognizedItems.push({
      ...randomFood,
      confidence: 0.85
    });
  }
  
  return recognizedItems.slice(0, 3); // Limit to 3 items max
}

function generateHealthTips(foodItems: FoodItem[]): string[] {
  const tips: string[] = [];
  const totalCalories = foodItems.reduce((sum, item) => sum + item.calories, 0);
  const totalProtein = foodItems.reduce((sum, item) => sum + item.protein, 0);
  const totalSodium = foodItems.reduce((sum, item) => sum + item.sodium, 0);
  
  if (totalCalories > 600) {
    tips.push("This is a high-calorie meal. Consider smaller portions or adding more vegetables.");
  }
  
  if (totalProtein > 25) {
    tips.push("Great protein content! This will help with muscle maintenance and satiety.");
  }
  
  if (totalSodium > 800) {
    tips.push("Watch your sodium intake. Try using herbs and spices instead of salt for flavor.");
  }
  
  const hasVegetables = foodItems.some(item => 
    item.name.toLowerCase().includes('broccoli') || 
    item.name.toLowerCase().includes('salad') ||
    item.fiber > 2
  );
  
  if (!hasVegetables) {
    tips.push("Consider adding more vegetables to increase fiber and micronutrients.");
  }
  
  if (tips.length === 0) {
    tips.push("This looks like a well-balanced meal! Keep up the good eating habits.");
  }
  
  return tips;
}

export async function analyzeFood(imageFile: File): Promise<AnalysisResult> {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  try {
    const foodItems = recognizeFoodItems(imageFile);
    const totalNutrition = foodItems.reduce(
      (total, item) => ({
        calories: total.calories + item.calories,
        protein: total.protein + item.protein,
        carbs: total.carbs + item.carbs,
        fat: total.fat + item.fat,
        fiber: total.fiber + item.fiber
      }),
      { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 }
    );
    
    const healthTips = generateHealthTips(foodItems);
    
    // Calculate overall health rating
    const avgHealthScore = foodItems.reduce((sum, item) => {
      const score = item.healthRating === 'Excellent' ? 4 : 
                   item.healthRating === 'Good' ? 3 :
                   item.healthRating === 'Fair' ? 2 : 1;
      return sum + score;
    }, 0) / foodItems.length;
    
    const overallHealthRating = avgHealthScore >= 3.5 ? 'Excellent' :
                               avgHealthScore >= 2.5 ? 'Good' :
                               avgHealthScore >= 1.5 ? 'Fair' : 'Needs Improvement';
    
    return {
      success: true,
      foodItems,
      totalNutrition,
      healthTips,
      overallHealthRating
    };
  } catch (error) {
    return {
      success: false,
      foodItems: [],
      totalNutrition: { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 },
      healthTips: ['Unable to analyze the image. Please try again with a clearer photo.'],
      overallHealthRating: 'Unknown'
    };
  }
}